<?php

include("../booking/db.php");

if($_POST){
	
	$name = $_POST["name"];
	$email = $_POST["email"];
	$subject = $_POST["subject"];
	$message = $_POST["message"];
	
	$query= "INSERT INTO tbl_contact (name,email,subject,message) 
					VALUES('$name','$email','$subject','$message')";
	mysqli_query($con,$query)or die(mysqli_error($con));
	
	echo "Contact form has been submitted successfully.";
}

?>